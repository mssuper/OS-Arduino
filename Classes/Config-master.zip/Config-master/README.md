# Config
This is a simple class to load and create settings from a configuration file.
